package com.khaos.app

import android.app.Activity
import android.os.Bundle

/**
 * Entra em ação quando o Khaos é o "app assistente padrão"
 * (segurar o botão home/power ou deslizar do canto, dependendo do celular).
 * Não mostra tela: só acorda o serviço e fecha.
 */
class AssistActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        KhaosService.start(this, KhaosService.ACTION_LISTEN_NOW)
        finish()
    }
}
