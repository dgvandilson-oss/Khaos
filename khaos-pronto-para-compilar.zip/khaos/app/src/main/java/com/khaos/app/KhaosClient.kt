package com.khaos.app

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Conversa com a API da Anthropic (Claude). Chamar sempre fora da thread principal. */
class KhaosClient(private val apiKey: String) {

    private val history = mutableListOf<Pair<String, String>>() // (role, texto)

    private val systemPrompt = """
        Você é o Khaos, o assistente de voz pessoal do usuário no celular, no estilo do Jarvis:
        educado, elegante, eficiente e com um toque sutil de humor refinado.
        Trate o usuário sempre por "senhor". Nunca diga que é um modelo de linguagem; você é o Khaos.
        Responda sempre em português do Brasil, de forma curta e natural, como numa conversa falada:
        no máximo 2 ou 3 frases. Não use markdown, listas, emojis nem símbolos, porque o texto será lido em voz alta.
    """.trimIndent()

    fun ask(userText: String): String {
        history.add("user" to userText)
        while (history.size > 12) history.removeAt(0)

        val messages = JSONArray()
        history.forEach { (role, text) ->
            messages.put(JSONObject().put("role", role).put("content", text))
        }

        val body = JSONObject()
            .put("model", MODEL)
            .put("max_tokens", 400)
            .put("system", systemPrompt)
            .put("messages", messages)

        val conn = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 15000
            conn.readTimeout = 40000
            conn.doOutput = true
            conn.setRequestProperty("content-type", "application/json")
            conn.setRequestProperty("x-api-key", apiKey)
            conn.setRequestProperty("anthropic-version", "2023-06-01")
            conn.outputStream.use { it.write(body.toString().toByteArray()) }

            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val raw = stream.bufferedReader().use { it.readText() }

            if (code !in 200..299) {
                history.removeAt(history.size - 1)
                return when (code) {
                    401 -> "Minha chave de API está inválida. Confere ela no aplicativo."
                    429 -> "Muitas requisições agora. Tenta de novo daqui a pouco."
                    else -> "Deu erro $code ao falar com o servidor."
                }
            }

            val content = JSONObject(raw).getJSONArray("content")
            val sb = StringBuilder()
            for (i in 0 until content.length()) {
                val block = content.getJSONObject(i)
                if (block.optString("type") == "text") sb.append(block.getString("text"))
            }
            val answer = sb.toString().trim().ifEmpty { "Não consegui pensar em uma resposta." }
            history.add("assistant" to answer)
            return answer
        } catch (e: Exception) {
            history.removeAt(history.size - 1)
            return "Estou sem conexão com a internet agora."
        } finally {
            conn.disconnect()
        }
    }

    companion object {
        const val MODEL = "claude-sonnet-5-5"
    }
}
