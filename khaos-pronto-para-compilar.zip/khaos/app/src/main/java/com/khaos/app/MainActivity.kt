package com.khaos.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var keyField: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pad = (20 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
            setBackgroundColor(Color.parseColor("#0E0E12"))
        }

        root.addView(TextView(this).apply {
            text = "KHAOS"
            textSize = 40f
            setTextColor(Color.parseColor("#B388FF"))
            gravity = Gravity.CENTER
        })
        root.addView(TextView(this).apply {
            text = "Seu assistente. Diga \"Khaos\" a qualquer momento."
            textSize = 14f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, pad)
        })

        keyField = EditText(this).apply {
            hint = "Chave da API da Anthropic (sk-ant-...)"
            setHintTextColor(Color.GRAY)
            setTextColor(Color.WHITE)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(prefs().getString(KhaosService.KEY_API, ""))
        }
        root.addView(keyField)

        root.addView(button("Salvar chave e ativar Khaos") { activate() })
        root.addView(button("Desativar Khaos") {
            KhaosService.start(this, KhaosService.ACTION_STOP)
            Toast.makeText(this, "Khaos desativado", Toast.LENGTH_SHORT).show()
        })
        root.addView(button("Definir Khaos como assistente do celular") {
            startActivity(Intent(Settings.ACTION_VOICE_INPUT_SETTINGS))
        })

        root.addView(TextView(this).apply {
            text = "\nDicas:\n" +
                "• Puxe os Ajustes Rápidos, toque no lápis e arraste o botão \"Khaos\" para lá.\n" +
                "• A notificação do Khaos tem os botões Falar e Parar.\n" +
                "• Em Ajustes > Apps > Apps padrão > Assistente digital, escolha Khaos para chamar segurando o botão home/power.\n" +
                "• Desative a otimização de bateria para o Khaos, senão o sistema pode encerrá-lo."
            textSize = 13f
            setTextColor(Color.LTGRAY)
        })

        setContentView(root)
    }

    private fun button(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        setOnClickListener { onClick() }
    }

    private fun prefs() = getSharedPreferences(KhaosService.PREFS, MODE_PRIVATE)

    private fun activate() {
        val key = keyField.text.toString().trim()
        if (key.isEmpty()) {
            Toast.makeText(this, "Cole a sua chave de API", Toast.LENGTH_SHORT).show()
            return
        }
        prefs().edit().putString(KhaosService.KEY_API, key).apply()

        val needed = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) needed.add(Manifest.permission.POST_NOTIFICATIONS)
        val missing = needed.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }

        if (missing.isNotEmpty()) {
            requestPermissions(missing.toTypedArray(), 1)
        } else {
            KhaosService.start(this)
            Toast.makeText(this, "Khaos ativo! Diga \"Khaos\".", Toast.LENGTH_LONG).show()
        }
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            KhaosService.start(this)
            Toast.makeText(this, "Khaos ativo! Diga \"Khaos\".", Toast.LENGTH_LONG).show()
        } else {
            Toast.makeText(this, "Sem microfone o Khaos não funciona.", Toast.LENGTH_LONG).show()
        }
    }
}
