package com.khaos.app

import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

/** Botão "Khaos" nos Ajustes Rápidos: toque e já pode falar. */
class KhaosTileService : TileService() {

    override fun onStartListening() {
        qsTile?.apply {
            state = Tile.STATE_INACTIVE
            label = "Khaos"
            updateTile()
        }
    }

    override fun onClick() {
        KhaosService.start(this, KhaosService.ACTION_LISTEN_NOW)
    }
}
