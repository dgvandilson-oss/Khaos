package com.khaos.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/**
 * Serviço em primeiro plano que fica escutando a palavra "Khaos".
 * Fluxo: ESCUTANDO_CHAMADA -> (ouviu "Khaos") -> ESCUTANDO_PEDIDO -> API -> fala -> volta ao início.
 */
class KhaosService : Service() {

    private enum class Mode { WAKE, COMMAND, BUSY }

    private val main = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var mode = Mode.WAKE
    private var running = false
    private var client: KhaosClient? = null

    // Variações que o reconhecedor costuma devolver para "Khaos"
    private val wakeWords = listOf("khaos", "kaos", "caos", "cáos", "cayos", "kaus")

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale("pt", "BR")
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(id: String?) {}
                    override fun onDone(id: String?) { main.post { afterSpeaking(id) } }
                    @Deprecated("Deprecated in Java")
                    override fun onError(id: String?) { main.post { afterSpeaking(id) } }
                })
                ttsReady = true
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Sempre chama startForeground primeiro (exigido após startForegroundService)
        startForegroundCompat()

        if (intent?.action == ACTION_STOP) {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }

        val key = getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_API, "").orEmpty()
        if (key.isBlank()) {
            speak("Abra o aplicativo e coloque a sua chave de API primeiro.", "err")
            stopSelf()
            return START_NOT_STICKY
        }
        if (client == null) client = KhaosClient(key)

        if (!running) {
            running = true
            main.post { startRecognizer() }
        }

        if (intent?.action == ACTION_LISTEN_NOW) {
            // Veio do botão dos Ajustes Rápidos ou do atalho de assistente: vai direto pro pedido.
            main.post { enterCommandMode(greet = true) }
        }
        return START_STICKY
    }

    // ---------------- reconhecimento de voz ----------------

    private fun startRecognizer() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            speak("Este celular não tem reconhecimento de voz disponível.", "err")
            stopSelf()
            return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).also {
            it.setRecognitionListener(listener)
        }
        listen()
    }

    private fun listen() {
        if (!running || mode == Mode.BUSY) return
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        }
        try {
            recognizer?.startListening(i)
        } catch (e: Exception) {
            restartSoon(1500)
        }
    }

    private fun restartSoon(delayMs: Long = 400) {
        if (!running) return
        main.postDelayed({
            if (mode != Mode.BUSY) listen()
        }, delayMs)
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onError(error: Int) {
            when (error) {
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> {
                    speak("Preciso da permissão do microfone.", "err")
                    stopSelf()
                }
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> {
                    recognizer?.cancel()
                    restartSoon(1000)
                }
                SpeechRecognizer.ERROR_CLIENT -> {
                    // Recria o reconhecedor para sair de estado ruim
                    main.postDelayed({ startRecognizer() }, 800)
                }
                else -> {
                    // Silêncio / nada reconhecido: se estava esperando o pedido, desiste e volta a esperar "Khaos"
                    if (mode == Mode.COMMAND) {
                        mode = Mode.WAKE
                        updateNotification("Chame o Khaos")
                    }
                    restartSoon()
                }
            }
        }

        override fun onResults(results: Bundle?) {
            val options = results
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                .orEmpty()
            if (options.isEmpty()) { restartSoon(); return }

            when (mode) {
                Mode.WAKE -> handleWake(options)
                Mode.COMMAND -> handleCommand(options.first())
                Mode.BUSY -> {}
            }
        }
    }

    private fun handleWake(options: List<String>) {
        for (text in options) {
            val lower = text.lowercase(Locale("pt", "BR"))
            val hit = wakeWords.firstOrNull { lower.contains(it) } ?: continue
            // Se a pessoa já falou o pedido junto ("Khaos, que horas são"), usa direto.
            val rest = lower.substringAfter(hit).trim(' ', ',', '.', '!', '?')
            if (rest.length >= 3) {
                handleCommand(rest)
            } else {
                enterCommandMode(greet = true)
            }
            return
        }
        restartSoon(200)
    }

    private fun enterCommandMode(greet: Boolean) {
        recognizer?.cancel()
        if (greet) {
            mode = Mode.BUSY
            updateNotification("Pode falar…")
            speak("Olá, senhor.", "greet")
        } else {
            mode = Mode.COMMAND
            listen()
        }
    }

    private fun handleCommand(text: String) {
        mode = Mode.BUSY
        updateNotification("Pensando…")
        val c = client ?: return
        Thread {
            val answer = c.ask(text)
            main.post { speak(answer, "answer") }
        }.start()
    }

    // ---------------- fala ----------------

    private fun speak(text: String, id: String) {
        if (!ttsReady) {
            // TTS ainda inicializando: tenta de novo em instantes
            main.postDelayed({ speak(text, id) }, 300)
            return
        }
        recognizer?.cancel() // não deixa o Khaos ouvir a própria voz
        updateNotification("Falando…")
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, id)
    }

    private fun afterSpeaking(id: String?) {
        if (!running) return
        when (id) {
            "greet" -> { mode = Mode.COMMAND; updateNotification("Ouvindo seu pedido…"); listen() }
            else -> { mode = Mode.WAKE; updateNotification("Chame o Khaos"); restartSoon(300) }
        }
    }

    // ---------------- notificação ----------------

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(CHANNEL, "Khaos", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
    }

    private fun buildNotification(text: String): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val talk = PendingIntent.getService(
            this, 1,
            Intent(this, KhaosService::class.java).setAction(ACTION_LISTEN_NOW),
            PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 2,
            Intent(this, KhaosService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CHANNEL)
            .setContentTitle("Khaos")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(null, "Falar", talk).build())
            .addAction(Notification.Action.Builder(null, "Parar", stop).build())
            .build()
    }

    private fun startForegroundCompat() {
        val n = buildNotification("Chame o Khaos")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    private fun updateNotification(text: String) {
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification(text))
    }

    override fun onDestroy() {
        running = false
        main.removeCallbacksAndMessages(null)
        recognizer?.destroy()
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }

    companion object {
        const val ACTION_LISTEN_NOW = "com.khaos.app.LISTEN_NOW"
        const val ACTION_STOP = "com.khaos.app.STOP"
        const val PREFS = "khaos"
        const val KEY_API = "api_key"
        private const val CHANNEL = "khaos_channel"
        private const val NOTIF_ID = 42

        fun start(ctx: Context, action: String? = null) {
            val i = Intent(ctx, KhaosService::class.java)
            if (action != null) i.action = action
            ctx.startForegroundService(i)
        }
    }
}
