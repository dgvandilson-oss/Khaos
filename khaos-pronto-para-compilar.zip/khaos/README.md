# Khaos — assistente de voz para Android

Diga "Khaos" com o celular desbloqueado ou em segundo plano e ele responde por voz, usando a IA Claude.

## Como instalar

1. Instale o **Android Studio** (gratuito) e abra esta pasta (`khaos`). Ele baixa tudo sozinho.
2. Conecte o celular com **Depuração USB** ativada (ou use um emulador) e clique em **Run ▶**.
3. Pegue uma chave de API em https://console.anthropic.com, abra o app Khaos, cole a chave e toque em **Salvar chave e ativar Khaos**.
4. Conceda as permissões de microfone e notificação.

## Como chamar o Khaos

- **Por voz:** diga "Khaos" (ou "Khaos, que horas são?") — ele responde "Olá, senhor." e ouve o pedido.
- **Botão nos Ajustes Rápidos:** puxe a barra de cima, toque no lápis e arraste o botão "Khaos".
- **Notificação:** tem os botões **Falar** e **Parar**.
- **Atalho do sistema:** Ajustes > Apps > Apps padrão > Assistente digital > Khaos (aí segurar home/power chama ele).

## Limitações

- O reconhecimento de "Khaos" usa o reconhecedor de voz do Google, não um detector dedicado de palavra de ativação. Ele pode errar ou gastar mais bateria que "Ok Google". Se o celular tiver otimização de bateria agressiva (Xiaomi, Samsung etc.), desative-a para o Khaos.
- Alguns celulares tocam um "bip" a cada ciclo de escuta.
- O Android não permite reiniciar o microfone sozinho após religar o celular: abra o app uma vez depois de reiniciar.
- A chave de API fica salva no celular em texto simples (SharedPreferences). Use uma chave só para isso, com limite de gasto.
- Cada pergunta consome créditos da sua conta da API.
- Este código não foi compilado nem testado em um aparelho; pode precisar de pequenos ajustes.
